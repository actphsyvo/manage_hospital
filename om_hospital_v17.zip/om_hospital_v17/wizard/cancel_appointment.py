from odoo import models, api, fields


class CancelAppointmentWizard(models.TransientModel):
    _name = "cancel.appointment.wizard"
    _description = "Cancel Appointment Wizard"

    # Fixed: was incorrectly linked to hospital.patient instead of hospital.appointment
    appointment_id = fields.Many2one(
        'hospital.appointment', string='Appointment', required=True
    )
    reason = fields.Text(string='Cancellation Reason')

    def action_cancel(self):
        """Cancel the linked appointment and close the wizard."""
        for record in self:
            if record.appointment_id:
                record.appointment_id.state = 'canceled'
        return {'type': 'ir.actions.act_window_close'}
