from odoo import fields, models


class PatientTag(models.Model):
    _name = "patient.tag"
    _description = "Patient Tag"

    name = fields.Char(string='Tag Name', required=True)
    active = fields.Boolean(string='Active', default=True)
    # color (Integer) is used by many2many_tags widget with color_field option
    color = fields.Integer(string='Color Index')
    # color_2 kept for compatibility; 'color' widget was removed in v17, use 'color_picker'
    color_2 = fields.Char(string='Color (Hex)')
