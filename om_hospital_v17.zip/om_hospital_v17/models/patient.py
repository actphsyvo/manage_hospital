from odoo import api, fields, models
from datetime import date


class HospitalPatient(models.Model):
    _name = "hospital.patient"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "Hospital Patient"

    name = fields.Char(string='Name', tracking=True, required=True)
    ref = fields.Char(string='Reference', tracking=True, help='Patient unique identifier', required=True)
    # In Odoo 17, computed fields that are not stored still need store=False (default),
    # but the compute decorator pattern is unchanged.
    age = fields.Integer(string='Age', compute='_compute_age', tracking=True, store=False)
    gender = fields.Selection(
        [('male', 'Male'), ('female', 'Female')],
        string='Gender', tracking=True, required=True
    )
    active = fields.Boolean(string='Active', default=True, tracking=True)
    date_of_birth = fields.Date(string='Date of Birth', tracking=True, required=True)
    appointment_id = fields.Many2one('hospital.appointment', string='Appointments')
    # Odoo 17: fields.Image is still supported; max_width/max_height are recommended
    image = fields.Image(string='Image', max_width=1024, max_height=1024)
    tag_ids = fields.Many2many('patient.tag', string='Tags')

    @api.depends('date_of_birth')
    def _compute_age(self):
        today = date.today()
        for record in self:
            if record.date_of_birth:
                record.age = today.year - record.date_of_birth.year
            else:
                record.age = 0
