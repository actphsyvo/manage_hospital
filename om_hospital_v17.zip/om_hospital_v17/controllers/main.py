from odoo import http
from odoo.http import request


class Hospital(http.Controller):

    @http.route('/patient_webform', type='http', auth='public', website=True)
    def patient_webform(self, **kw):
        return request.render('om_hospital.create_patient', {})

    @http.route('/create/webpatient', type='http', auth='public', website=True, methods=['POST'], csrf=True)
    def create_webpatient(self, **kw):
        # Only pass known safe fields to create()
        allowed_fields = {'name', 'ref', 'date_of_birth', 'gender'}
        vals = {k: v for k, v in kw.items() if k in allowed_fields}
        request.env['hospital.patient'].sudo().create(vals)
        return request.render('om_hospital.patient_thanks', {})
