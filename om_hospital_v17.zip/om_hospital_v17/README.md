# Hospital Management — Odoo 17 Community

**Original author:** Martin Kalema  
**Migrated to:** Odoo 17 Community Edition  
**Module technical name:** `om_hospital`

---

## Installation

1. Copy the `om_hospital` folder into your Odoo 17 addons directory.
2. Restart the Odoo server.
3. Activate developer mode, go to **Apps → Update Apps List**.
4. Search for **Hospital Management** and install.

---

## Migration Notes: Odoo 16 → 17

### Python / Models

| File | Change |
|---|---|
| `models/appointment.py` | All action methods (`action_in_consultation`, `action_done`, `action_cancel`, `action_draft`, `action_test`) were incorrectly decorated `@staticmethod` while still accepting `self`. They silently did nothing. All converted to proper instance methods. |
| `models/appointment.py` | `action_cancel` referenced `self.env.ref('om_hospital.action_cancel_appointment').read()[0]` which broke because the action isn't always available at that path during install. Replaced with an explicit `act_window` dict. |
| `models/patient.py` | Added `max_width`/`max_height` to `fields.Image` (recommended in v17). |
| `wizard/cancel_appointment.py` | `appointment_id` was linked to `hospital.patient` (wrong model). Fixed to `hospital.appointment`. `action_cancel` had a bare `return` statement (broken). Implemented correctly to set `state = 'canceled'` and close the wizard. |
| `controllers/main.py` | Changed `auth='user'` to `auth='public'` so unauthenticated visitors can access the web form. Added a field allowlist in `create_webpatient` to prevent mass-assignment of arbitrary fields via POST. |

### XML Views

| Change | v16 | v17 |
|---|---|---|
| List view tag | `<tree>` | `<list>` (tree still works but list is canonical) |
| Chatter block | `<div class="oe_chatter"><field .../></div>` | `<chatter/>` |
| Button visibility | `states="draft"` attribute | `invisible="state != 'draft'"` |
| Column visibility | `attrs="{'column_invisible': [...]}"` | `column_invisible="parent.field"` |
| HTML widget options | `{'collaborative': true, 'resizable': true}` | `{'resizable': true}` — `collaborative` removed in v17 Community |
| Activity image | `activity_image('model', 'field', id)` QWeb helper | `/web/image/model/id/field/WxH` URL |
| Color widget | `widget="color"` | `widget="color_picker"` — `color` widget removed |
| view_mode | `tree,form` | `list,form` |
| website.page | `website_published` field | `is_published` field |
| website.page | `type` field | Removed in v17 |
| Bootstrap | v4 classes (`radio-inline`, `pull-left`) | Bootstrap 5 (`form-check-inline`, `float-start`) |

---

## Known Limitations

- The `collaborative` HTML editor feature is an Odoo Enterprise feature and was never available in Community. It has been removed from the prescription field options.
- The website menu `parent_id` search has been made more robust to avoid depending on a hardcoded website record.
