# -*- coding: utf-8 -*-
{
    'name': 'Hospital Management System',
    'version': '17.0.1.0.0',
    'category': 'Healthcare',
    'summary': 'Complete Hospital Management: Patients, Appointments, Doctors & Invoicing',
    'description': """
        Hospital Management System for Odoo 17 Community
        =================================================
        Features:
        - Patient Information Management
        - Doctor / Physician Management
        - Appointment Scheduling & Booking
        - Medical Records & Diagnosis
        - Prescription Management
        - Laboratory Tests
        - Invoicing & Billing Integration
        - Patient Visit History
        - Department & Ward Management
        - Dashboard & Reporting
    """,
    'author': 'Custom Development',
    'website': '',
    'license': 'LGPL-3',
    'depends': [
        'base',
        'mail',
        'account',
        'product',
        'calendar',
        'web',
    ],
    'data': [
        'security/hospital_security.xml',
        'security/ir.model.access.csv',
        'data/hospital_sequence.xml',
        'data/hospital_data.xml',
        'views/hospital_patient_views.xml',
        'views/hospital_doctor_views.xml',
        'views/hospital_appointment_views.xml',
        'views/hospital_prescription_views.xml',
        'views/hospital_lab_test_views.xml',
        'views/hospital_invoice_views.xml',
        'views/hospital_department_views.xml',
        'views/hospital_menu.xml',
        'report/patient_card_report.xml',
        'report/appointment_report.xml',
        'report/prescription_report.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'hospital_management/static/src/css/hospital.css',
        ],
    },
    'images': ['static/description/icon.png'],
    'installable': True,
    'application': True,
    'auto_install': False,
}
