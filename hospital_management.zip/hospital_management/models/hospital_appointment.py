# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError
from datetime import datetime, timedelta


class HospitalAppointment(models.Model):
    _name = 'hospital.appointment'
    _description = 'Hospital Appointment'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _rec_name = 'name'
    _order = 'appointment_date desc'

    name = fields.Char(string='Appointment Ref', readonly=True, default='New', copy=False)

    # ─── Core Fields ──────────────────────────────────────────────────────────
    patient_id = fields.Many2one('hospital.patient', string='Patient', required=True, tracking=True)
    doctor_id = fields.Many2one('hospital.doctor', string='Doctor', required=True, tracking=True)
    department_id = fields.Many2one('hospital.department', string='Department',
                                    related='doctor_id.department_id', store=True)

    appointment_date = fields.Datetime(string='Appointment Date & Time', required=True, tracking=True)
    appointment_end = fields.Datetime(string='End Time', compute='_compute_end_time', store=True)
    duration = fields.Integer(string='Duration (mins)',
                              related='doctor_id.consultation_duration', readonly=False, store=True)

    appointment_type = fields.Selection([
        ('consultation', 'Consultation'),
        ('follow_up', 'Follow-Up'),
        ('emergency', 'Emergency'),
        ('routine_checkup', 'Routine Check-Up'),
        ('lab_result', 'Lab Result Review'),
        ('procedure', 'Procedure'),
    ], string='Appointment Type', default='consultation', required=True, tracking=True)

    priority = fields.Selection([
        ('0', 'Normal'),
        ('1', 'Urgent'),
        ('2', 'Emergency'),
    ], string='Priority', default='0')

    # ─── Medical Details ──────────────────────────────────────────────────────
    chief_complaint = fields.Text(string='Chief Complaint / Reason for Visit')
    symptoms = fields.Text(string='Symptoms')

    # Vital Signs
    temperature = fields.Float(string='Temperature (°C)', digits=(5, 1))
    blood_pressure = fields.Char(string='Blood Pressure (mmHg)')
    pulse_rate = fields.Integer(string='Pulse Rate (bpm)')
    respiratory_rate = fields.Integer(string='Respiratory Rate')
    oxygen_saturation = fields.Float(string='O₂ Saturation (%)', digits=(5, 1))
    weight = fields.Float(string='Weight (kg)', digits=(5, 2))
    height = fields.Float(string='Height (cm)', digits=(5, 1))
    bmi = fields.Float(string='BMI', compute='_compute_bmi', store=True)

    # Doctor Notes
    diagnosis = fields.Text(string='Diagnosis')
    treatment_plan = fields.Text(string='Treatment Plan')
    doctor_notes = fields.Text(string='Doctor Notes (Internal)')
    follow_up_date = fields.Date(string='Follow-Up Date')
    follow_up_notes = fields.Text(string='Follow-Up Instructions')

    # ─── Relations ────────────────────────────────────────────────────────────
    prescription_ids = fields.One2many('hospital.prescription', 'appointment_id', string='Prescriptions')
    prescription_count = fields.Integer(compute='_compute_prescription_count')

    lab_test_ids = fields.One2many('hospital.lab.test', 'appointment_id', string='Lab Tests')
    lab_test_count = fields.Integer(compute='_compute_lab_test_count')

    invoice_id = fields.Many2one('account.move', string='Invoice', copy=False)
    invoice_state = fields.Selection(related='invoice_id.state', string='Invoice Status', store=True)

    # ─── Status ───────────────────────────────────────────────────────────────
    state = fields.Selection([
        ('draft', 'Scheduled'),
        ('confirmed', 'Confirmed'),
        ('in_progress', 'In Progress'),
        ('done', 'Completed'),
        ('invoiced', 'Invoiced'),
        ('cancelled', 'Cancelled'),
        ('no_show', 'No Show'),
    ], string='Status', default='draft', tracking=True)

    cancellation_reason = fields.Text(string='Cancellation Reason')
    notes = fields.Text(string='Additional Notes')

    # ─── Compute ──────────────────────────────────────────────────────────────
    @api.depends('appointment_date', 'duration')
    def _compute_end_time(self):
        for rec in self:
            if rec.appointment_date and rec.duration:
                rec.appointment_end = rec.appointment_date + timedelta(minutes=rec.duration)
            else:
                rec.appointment_end = rec.appointment_date

    @api.depends('weight', 'height')
    def _compute_bmi(self):
        for rec in self:
            if rec.weight and rec.height and rec.height > 0:
                height_m = rec.height / 100
                rec.bmi = round(rec.weight / (height_m ** 2), 1)
            else:
                rec.bmi = 0.0

    def _compute_prescription_count(self):
        for rec in self:
            rec.prescription_count = len(rec.prescription_ids)

    def _compute_lab_test_count(self):
        for rec in self:
            rec.lab_test_count = len(rec.lab_test_ids)

    # ─── ORM ──────────────────────────────────────────────────────────────────
    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', 'New') == 'New':
                vals['name'] = self.env['ir.sequence'].next_by_code('hospital.appointment') or 'New'
        return super().create(vals_list)

    @api.constrains('appointment_date', 'doctor_id')
    def _check_doctor_availability(self):
        for rec in self:
            if not rec.appointment_date or not rec.doctor_id:
                continue
            # Check for overlapping appointments for the same doctor
            domain = [
                ('doctor_id', '=', rec.doctor_id.id),
                ('id', '!=', rec.id),
                ('state', 'not in', ['cancelled', 'no_show']),
                ('appointment_date', '<', rec.appointment_end),
                ('appointment_end', '>', rec.appointment_date),
            ]
            overlap = self.search(domain, limit=1)
            if overlap:
                raise ValidationError(_(
                    'Doctor %s already has an appointment (%s) at this time slot.'
                ) % (rec.doctor_id.name, overlap.name))

    # ─── State Actions ────────────────────────────────────────────────────────
    def action_confirm(self):
        self.write({'state': 'confirmed'})
        # Send confirmation notification
        for rec in self:
            rec.message_post(
                body=_('Appointment confirmed for %s on %s.') % (
                    rec.patient_id.name,
                    rec.appointment_date.strftime('%d/%m/%Y %H:%M')
                ),
                message_type='notification',
            )

    def action_start(self):
        self.write({'state': 'in_progress'})

    def action_done(self):
        self.write({'state': 'done'})
        # Auto-activate patient if still 'new'
        for rec in self:
            if rec.patient_id.state == 'new':
                rec.patient_id.action_activate()

    def action_cancel(self):
        self.write({'state': 'cancelled'})

    def action_no_show(self):
        self.write({'state': 'no_show'})

    def action_reset_draft(self):
        self.write({'state': 'draft'})

    # ─── Invoice ──────────────────────────────────────────────────────────────
    def action_create_invoice(self):
        self.ensure_one()
        if self.invoice_id:
            return self._open_invoice()

        product_id = self.env.ref('hospital_management.product_consultation_fee', raise_if_not_found=False)
        invoice_line_vals = [{
            'name': _('Consultation: %s - Dr. %s') % (self.name, self.doctor_id.name),
            'quantity': 1,
            'price_unit': self.doctor_id.consultation_fee,
        }]
        if product_id:
            invoice_line_vals[0]['product_id'] = product_id.id

        invoice = self.env['account.move'].create({
            'move_type': 'out_invoice',
            'partner_id': self.patient_id.partner_id.id,
            'hospital_patient_id': self.patient_id.id,
            'hospital_appointment_id': self.id,
            'invoice_date': fields.Date.today(),
            'invoice_line_ids': [(0, 0, line) for line in invoice_line_vals],
            'narration': _('Appointment %s dated %s') % (self.name, self.appointment_date),
        })

        self.write({'invoice_id': invoice.id, 'state': 'invoiced'})
        return self._open_invoice()

    def _open_invoice(self):
        return {
            'name': _('Invoice'),
            'type': 'ir.actions.act_window',
            'res_model': 'account.move',
            'res_id': self.invoice_id.id,
            'view_mode': 'form',
        }

    def action_view_prescriptions(self):
        return {
            'name': _('Prescriptions'),
            'type': 'ir.actions.act_window',
            'res_model': 'hospital.prescription',
            'view_mode': 'list,form',
            'domain': [('appointment_id', '=', self.id)],
            'context': {
                'default_appointment_id': self.id,
                'default_patient_id': self.patient_id.id,
                'default_doctor_id': self.doctor_id.id,
            },
        }

    def action_view_lab_tests(self):
        return {
            'name': _('Lab Tests'),
            'type': 'ir.actions.act_window',
            'res_model': 'hospital.lab.test',
            'view_mode': 'list,form',
            'domain': [('appointment_id', '=', self.id)],
            'context': {
                'default_appointment_id': self.id,
                'default_patient_id': self.patient_id.id,
                'default_doctor_id': self.doctor_id.id,
            },
        }

    def action_print_appointment(self):
        return self.env.ref('hospital_management.action_report_appointment').report_action(self)
