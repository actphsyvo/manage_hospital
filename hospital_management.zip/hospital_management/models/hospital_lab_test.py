# -*- coding: utf-8 -*-
from odoo import api, fields, models, _


class HospitalLabTest(models.Model):
    _name = 'hospital.lab.test'
    _description = 'Laboratory Test'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _rec_name = 'name'
    _order = 'test_date desc'

    name = fields.Char(string='Test Ref', readonly=True, default='New', copy=False)

    patient_id = fields.Many2one('hospital.patient', string='Patient', required=True, tracking=True)
    doctor_id = fields.Many2one('hospital.doctor', string='Requested By', tracking=True)
    appointment_id = fields.Many2one('hospital.appointment', string='Related Appointment')

    test_type_id = fields.Many2one('hospital.lab.test.type', string='Test Type', required=True)
    test_date = fields.Datetime(string='Test Date', default=fields.Datetime.now)
    result_date = fields.Datetime(string='Result Date')

    # Results
    result = fields.Text(string='Results / Findings')
    normal_range = fields.Char(string='Normal Range', related='test_type_id.normal_range')
    result_interpretation = fields.Selection([
        ('normal', 'Normal'),
        ('low', 'Low'),
        ('high', 'High'),
        ('critical', 'Critical'),
        ('inconclusive', 'Inconclusive'),
    ], string='Interpretation')

    technician_id = fields.Many2one('res.users', string='Lab Technician')
    notes = fields.Text(string='Notes')
    attachment_ids = fields.Many2many('ir.attachment', string='Result Attachments')

    test_line_ids = fields.One2many('hospital.lab.test.line', 'test_id', string='Test Parameters')

    invoice_id = fields.Many2one('account.move', string='Invoice')

    state = fields.Selection([
        ('requested', 'Requested'),
        ('sample_collected', 'Sample Collected'),
        ('in_progress', 'In Progress'),
        ('completed', 'Completed'),
        ('reviewed', 'Reviewed by Doctor'),
        ('cancelled', 'Cancelled'),
    ], string='Status', default='requested', tracking=True)

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', 'New') == 'New':
                vals['name'] = self.env['ir.sequence'].next_by_code('hospital.lab.test') or 'New'
        return super().create(vals_list)

    def action_collect_sample(self):
        self.write({'state': 'sample_collected'})

    def action_start(self):
        self.write({'state': 'in_progress'})

    def action_complete(self):
        self.write({
            'state': 'completed',
            'result_date': fields.Datetime.now(),
        })

    def action_review(self):
        self.write({'state': 'reviewed'})

    def action_cancel(self):
        self.write({'state': 'cancelled'})

    def action_create_invoice(self):
        self.ensure_one()
        invoice = self.env['account.move'].create({
            'move_type': 'out_invoice',
            'partner_id': self.patient_id.partner_id.id,
            'hospital_patient_id': self.patient_id.id,
            'invoice_date': fields.Date.today(),
            'invoice_line_ids': [(0, 0, {
                'name': _('Lab Test: %s') % self.test_type_id.name,
                'quantity': 1,
                'price_unit': self.test_type_id.price,
            })],
        })
        self.invoice_id = invoice
        return {
            'name': _('Invoice'),
            'type': 'ir.actions.act_window',
            'res_model': 'account.move',
            'res_id': invoice.id,
            'view_mode': 'form',
        }


class HospitalLabTestLine(models.Model):
    _name = 'hospital.lab.test.line'
    _description = 'Lab Test Parameter Line'

    test_id = fields.Many2one('hospital.lab.test', string='Lab Test', required=True, ondelete='cascade')
    parameter = fields.Char(string='Parameter', required=True)
    result_value = fields.Char(string='Result Value')
    unit = fields.Char(string='Unit')
    normal_range = fields.Char(string='Normal Range')
    interpretation = fields.Selection([
        ('normal', 'Normal'),
        ('low', 'Low'),
        ('high', 'High'),
        ('critical', 'Critical'),
    ], string='Interpretation')


class HospitalLabTestType(models.Model):
    _name = 'hospital.lab.test.type'
    _description = 'Lab Test Type'

    name = fields.Char(string='Test Name', required=True)
    code = fields.Char(string='Code')
    category = fields.Selection([
        ('hematology', 'Hematology'),
        ('biochemistry', 'Biochemistry'),
        ('microbiology', 'Microbiology'),
        ('immunology', 'Immunology'),
        ('pathology', 'Pathology'),
        ('radiology', 'Radiology'),
        ('urine', 'Urinalysis'),
        ('other', 'Other'),
    ], string='Category', default='biochemistry')
    price = fields.Float(string='Test Price', digits=(16, 2))
    normal_range = fields.Char(string='Normal Range')
    sample_type = fields.Selection([
        ('blood', 'Blood'),
        ('urine', 'Urine'),
        ('stool', 'Stool'),
        ('sputum', 'Sputum'),
        ('swab', 'Swab'),
        ('tissue', 'Tissue'),
        ('other', 'Other'),
    ], string='Sample Type', default='blood')
    turnaround_hours = fields.Integer(string='Turnaround Time (hours)', default=24)
    description = fields.Text(string='Description')
    active = fields.Boolean(default=True)
