# -*- coding: utf-8 -*-
from odoo import api, fields, models, _


class HospitalDoctor(models.Model):
    _name = 'hospital.doctor'
    _description = 'Hospital Doctor'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _rec_name = 'name'
    _order = 'name asc'

    name = fields.Char(string='Doctor Name', required=True, tracking=True)
    doctor_id = fields.Char(string='Doctor ID', readonly=True, default='New', copy=False)
    image = fields.Binary(string='Photo', attachment=True)
    active = fields.Boolean(default=True)

    # ─── Professional Info ────────────────────────────────────────────────────
    specialization = fields.Char(string='Specialization', required=True)
    qualification = fields.Char(string='Qualification')
    license_no = fields.Char(string='Medical License No.')
    experience_years = fields.Integer(string='Years of Experience')
    department_id = fields.Many2one('hospital.department', string='Department')

    # ─── Contact ──────────────────────────────────────────────────────────────
    phone = fields.Char(string='Phone')
    mobile = fields.Char(string='Mobile')
    email = fields.Char(string='Email')

    # ─── Availability ─────────────────────────────────────────────────────────
    consultation_fee = fields.Float(string='Consultation Fee', digits=(16, 2))
    consultation_duration = fields.Integer(string='Avg. Consultation Duration (mins)', default=20)

    available_monday = fields.Boolean(string='Monday', default=True)
    available_tuesday = fields.Boolean(string='Tuesday', default=True)
    available_wednesday = fields.Boolean(string='Wednesday', default=True)
    available_thursday = fields.Boolean(string='Thursday', default=True)
    available_friday = fields.Boolean(string='Friday', default=True)
    available_saturday = fields.Boolean(string='Saturday', default=False)
    available_sunday = fields.Boolean(string='Sunday', default=False)

    morning_start = fields.Float(string='Morning Start', default=8.0)
    morning_end = fields.Float(string='Morning End', default=12.0)
    afternoon_start = fields.Float(string='Afternoon Start', default=14.0)
    afternoon_end = fields.Float(string='Afternoon End', default=18.0)

    notes = fields.Text(string='Notes')

    # ─── Relations ────────────────────────────────────────────────────────────
    appointment_ids = fields.One2many('hospital.appointment', 'doctor_id', string='Appointments')
    appointment_count = fields.Integer(string='Appointments', compute='_compute_appointment_count')

    patient_count = fields.Integer(string='Patients', compute='_compute_patient_count')

    user_id = fields.Many2one('res.users', string='Linked User')

    state = fields.Selection([
        ('active', 'Active'),
        ('on_leave', 'On Leave'),
        ('inactive', 'Inactive'),
    ], string='Status', default='active', tracking=True)

    # ─── Compute ──────────────────────────────────────────────────────────────
    def _compute_appointment_count(self):
        for rec in self:
            rec.appointment_count = self.env['hospital.appointment'].search_count([('doctor_id', '=', rec.id)])

    def _compute_patient_count(self):
        for rec in self:
            patient_ids = self.env['hospital.appointment'].search([('doctor_id', '=', rec.id)]).mapped('patient_id')
            rec.patient_count = len(patient_ids)

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('doctor_id', 'New') == 'New':
                vals['doctor_id'] = self.env['ir.sequence'].next_by_code('hospital.doctor') or 'New'
        return super().create(vals_list)

    def action_view_appointments(self):
        return {
            'name': _('Appointments'),
            'type': 'ir.actions.act_window',
            'res_model': 'hospital.appointment',
            'view_mode': 'list,form,calendar',
            'domain': [('doctor_id', '=', self.id)],
            'context': {'default_doctor_id': self.id},
        }

    def action_set_on_leave(self):
        self.write({'state': 'on_leave'})

    def action_set_active(self):
        self.write({'state': 'active'})
