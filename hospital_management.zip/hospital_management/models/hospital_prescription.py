# -*- coding: utf-8 -*-
from odoo import api, fields, models, _


class HospitalPrescription(models.Model):
    _name = 'hospital.prescription'
    _description = 'Medical Prescription'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _rec_name = 'name'
    _order = 'prescription_date desc'

    name = fields.Char(string='Prescription No', readonly=True, default='New', copy=False)

    patient_id = fields.Many2one('hospital.patient', string='Patient', required=True, tracking=True)
    doctor_id = fields.Many2one('hospital.doctor', string='Prescribed By', required=True, tracking=True)
    appointment_id = fields.Many2one('hospital.appointment', string='Related Appointment')

    prescription_date = fields.Date(string='Date', default=fields.Date.today, required=True)
    valid_till = fields.Date(string='Valid Till')

    diagnosis = fields.Text(string='Diagnosis')
    notes = fields.Text(string='Instructions to Patient')

    medicine_line_ids = fields.One2many('hospital.prescription.line', 'prescription_id', string='Medicines')

    state = fields.Selection([
        ('draft', 'Draft'),
        ('prescribed', 'Prescribed'),
        ('dispensed', 'Dispensed'),
        ('cancelled', 'Cancelled'),
    ], string='Status', default='draft', tracking=True)

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', 'New') == 'New':
                vals['name'] = self.env['ir.sequence'].next_by_code('hospital.prescription') or 'New'
        return super().create(vals_list)

    def action_prescribe(self):
        self.write({'state': 'prescribed'})

    def action_dispense(self):
        self.write({'state': 'dispensed'})

    def action_cancel(self):
        self.write({'state': 'cancelled'})

    def action_reset(self):
        self.write({'state': 'draft'})

    def action_print_prescription(self):
        return self.env.ref('hospital_management.action_report_prescription').report_action(self)


class HospitalPrescriptionLine(models.Model):
    _name = 'hospital.prescription.line'
    _description = 'Prescription Medicine Line'

    prescription_id = fields.Many2one('hospital.prescription', string='Prescription', required=True, ondelete='cascade')
    medicine_name = fields.Char(string='Medicine / Drug', required=True)
    dosage = fields.Char(string='Dosage', placeholder='e.g. 500mg')
    route = fields.Selection([
        ('oral', 'Oral'),
        ('iv', 'Intravenous'),
        ('im', 'Intramuscular'),
        ('topical', 'Topical'),
        ('sublingual', 'Sublingual'),
        ('inhaled', 'Inhaled'),
        ('rectal', 'Rectal'),
        ('ophthalmic', 'Ophthalmic'),
    ], string='Route', default='oral')
    frequency = fields.Char(string='Frequency', placeholder='e.g. Twice daily')
    duration = fields.Char(string='Duration', placeholder='e.g. 7 days')
    quantity = fields.Float(string='Quantity', digits=(10, 0))
    instructions = fields.Char(string='Special Instructions', placeholder='e.g. Take after meals')
    notes = fields.Text(string='Notes')
