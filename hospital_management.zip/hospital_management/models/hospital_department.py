# -*- coding: utf-8 -*-
from odoo import fields, models


class HospitalDepartment(models.Model):
    _name = 'hospital.department'
    _description = 'Hospital Department'
    _rec_name = 'name'

    name = fields.Char(string='Department Name', required=True)
    code = fields.Char(string='Code')
    head_doctor_id = fields.Many2one('hospital.doctor', string='Head of Department')
    description = fields.Text(string='Description')
    active = fields.Boolean(default=True)

    doctor_ids = fields.One2many('hospital.doctor', 'department_id', string='Doctors')
    doctor_count = fields.Integer(compute='_compute_doctor_count', string='Doctors')

    def _compute_doctor_count(self):
        for rec in self:
            rec.doctor_count = len(rec.doctor_ids)
