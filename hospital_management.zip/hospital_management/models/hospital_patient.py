# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError
from datetime import date


class HospitalPatient(models.Model):
    _name = 'hospital.patient'
    _description = 'Hospital Patient'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _rec_name = 'name'
    _order = 'name asc'

    # ─── Basic Information ────────────────────────────────────────────────────
    name = fields.Char(string='Full Name', required=True, tracking=True)
    patient_id = fields.Char(string='Patient ID', readonly=True, default='New', copy=False)
    image = fields.Binary(string='Photo', attachment=True)
    active = fields.Boolean(default=True)

    gender = fields.Selection([
        ('male', 'Male'),
        ('female', 'Female'),
        ('other', 'Other'),
    ], string='Gender', required=True, tracking=True)

    date_of_birth = fields.Date(string='Date of Birth', required=True)
    age = fields.Integer(string='Age', compute='_compute_age', store=True)

    blood_group = fields.Selection([
        ('a+', 'A+'), ('a-', 'A-'),
        ('b+', 'B+'), ('b-', 'B-'),
        ('o+', 'O+'), ('o-', 'O-'),
        ('ab+', 'AB+'), ('ab-', 'AB-'),
    ], string='Blood Group')

    marital_status = fields.Selection([
        ('single', 'Single'),
        ('married', 'Married'),
        ('divorced', 'Divorced'),
        ('widowed', 'Widowed'),
    ], string='Marital Status')

    # ─── Contact Details ──────────────────────────────────────────────────────
    phone = fields.Char(string='Phone', required=True, tracking=True)
    mobile = fields.Char(string='Mobile')
    email = fields.Char(string='Email')
    street = fields.Char(string='Street')
    city = fields.Char(string='City')
    state_id = fields.Many2one('res.country.state', string='State')
    country_id = fields.Many2one('res.country', string='Country')

    # ─── Emergency Contact ────────────────────────────────────────────────────
    emergency_contact_name = fields.Char(string='Emergency Contact Name')
    emergency_contact_phone = fields.Char(string='Emergency Contact Phone')
    emergency_contact_relation = fields.Char(string='Relation')

    # ─── Medical Information ──────────────────────────────────────────────────
    department_id = fields.Many2one('hospital.department', string='Department')
    primary_doctor_id = fields.Many2one('hospital.doctor', string='Primary Doctor')

    allergies = fields.Text(string='Known Allergies')
    chronic_diseases = fields.Text(string='Chronic Diseases')
    current_medications = fields.Text(string='Current Medications')
    notes = fields.Text(string='Notes / Remarks')

    # ─── Insurance ────────────────────────────────────────────────────────────
    has_insurance = fields.Boolean(string='Has Insurance')
    insurance_company = fields.Char(string='Insurance Company')
    insurance_policy_no = fields.Char(string='Policy Number')
    insurance_expiry = fields.Date(string='Insurance Expiry')

    # ─── Relations ────────────────────────────────────────────────────────────
    appointment_ids = fields.One2many('hospital.appointment', 'patient_id', string='Appointments')
    appointment_count = fields.Integer(string='Appointments', compute='_compute_appointment_count')

    prescription_ids = fields.One2many('hospital.prescription', 'patient_id', string='Prescriptions')
    prescription_count = fields.Integer(string='Prescriptions', compute='_compute_prescription_count')

    lab_test_ids = fields.One2many('hospital.lab.test', 'patient_id', string='Lab Tests')
    lab_test_count = fields.Integer(string='Lab Tests', compute='_compute_lab_test_count')

    invoice_ids = fields.One2many('account.move', 'hospital_patient_id', string='Invoices')
    invoice_count = fields.Integer(string='Invoices', compute='_compute_invoice_count')

    partner_id = fields.Many2one('res.partner', string='Linked Contact', copy=False)

    # ─── Status ───────────────────────────────────────────────────────────────
    state = fields.Selection([
        ('new', 'New'),
        ('active', 'Active'),
        ('discharged', 'Discharged'),
        ('deceased', 'Deceased'),
    ], string='Status', default='new', tracking=True)

    registration_date = fields.Date(string='Registration Date', default=fields.Date.today)

    # ─── Compute Methods ──────────────────────────────────────────────────────
    @api.depends('date_of_birth')
    def _compute_age(self):
        today = date.today()
        for rec in self:
            if rec.date_of_birth:
                rec.age = today.year - rec.date_of_birth.year - (
                    (today.month, today.day) < (rec.date_of_birth.month, rec.date_of_birth.day)
                )
            else:
                rec.age = 0

    def _compute_appointment_count(self):
        for rec in self:
            rec.appointment_count = self.env['hospital.appointment'].search_count([('patient_id', '=', rec.id)])

    def _compute_prescription_count(self):
        for rec in self:
            rec.prescription_count = self.env['hospital.prescription'].search_count([('patient_id', '=', rec.id)])

    def _compute_lab_test_count(self):
        for rec in self:
            rec.lab_test_count = self.env['hospital.lab.test'].search_count([('patient_id', '=', rec.id)])

    def _compute_invoice_count(self):
        for rec in self:
            rec.invoice_count = self.env['account.move'].search_count([('hospital_patient_id', '=', rec.id)])

    # ─── ORM Overrides ────────────────────────────────────────────────────────
    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('patient_id', 'New') == 'New':
                vals['patient_id'] = self.env['ir.sequence'].next_by_code('hospital.patient') or 'New'
            # Create a linked partner for invoicing
            if not vals.get('partner_id'):
                partner = self.env['res.partner'].create({
                    'name': vals.get('name'),
                    'phone': vals.get('phone'),
                    'mobile': vals.get('mobile'),
                    'email': vals.get('email'),
                    'customer_rank': 1,
                })
                vals['partner_id'] = partner.id
        return super().create(vals_list)

    def write(self, vals):
        result = super().write(vals)
        # Sync name/contact to linked partner
        for rec in self:
            if rec.partner_id:
                sync = {}
                if 'name' in vals:
                    sync['name'] = vals['name']
                if 'phone' in vals:
                    sync['phone'] = vals['phone']
                if 'email' in vals:
                    sync['email'] = vals['email']
                if sync:
                    rec.partner_id.write(sync)
        return result

    @api.constrains('date_of_birth')
    def _check_date_of_birth(self):
        for rec in self:
            if rec.date_of_birth and rec.date_of_birth > date.today():
                raise ValidationError(_('Date of birth cannot be in the future.'))

    # ─── Action Buttons ───────────────────────────────────────────────────────
    def action_view_appointments(self):
        return {
            'name': _('Appointments'),
            'type': 'ir.actions.act_window',
            'res_model': 'hospital.appointment',
            'view_mode': 'list,form,calendar',
            'domain': [('patient_id', '=', self.id)],
            'context': {'default_patient_id': self.id},
        }

    def action_view_prescriptions(self):
        return {
            'name': _('Prescriptions'),
            'type': 'ir.actions.act_window',
            'res_model': 'hospital.prescription',
            'view_mode': 'list,form',
            'domain': [('patient_id', '=', self.id)],
            'context': {'default_patient_id': self.id},
        }

    def action_view_lab_tests(self):
        return {
            'name': _('Lab Tests'),
            'type': 'ir.actions.act_window',
            'res_model': 'hospital.lab.test',
            'view_mode': 'list,form',
            'domain': [('patient_id', '=', self.id)],
            'context': {'default_patient_id': self.id},
        }

    def action_view_invoices(self):
        return {
            'name': _('Invoices'),
            'type': 'ir.actions.act_window',
            'res_model': 'account.move',
            'view_mode': 'list,form',
            'domain': [('hospital_patient_id', '=', self.id)],
            'context': {'default_hospital_patient_id': self.id, 'default_move_type': 'out_invoice'},
        }

    def action_create_invoice(self):
        self.ensure_one()
        return {
            'name': _('Create Invoice'),
            'type': 'ir.actions.act_window',
            'res_model': 'account.move',
            'view_mode': 'form',
            'context': {
                'default_hospital_patient_id': self.id,
                'default_partner_id': self.partner_id.id,
                'default_move_type': 'out_invoice',
            },
        }

    def action_new_appointment(self):
        self.ensure_one()
        return {
            'name': _('New Appointment'),
            'type': 'ir.actions.act_window',
            'res_model': 'hospital.appointment',
            'view_mode': 'form',
            'context': {'default_patient_id': self.id},
        }

    def action_activate(self):
        self.write({'state': 'active'})

    def action_discharge(self):
        self.write({'state': 'discharged'})

    def action_print_patient_card(self):
        return self.env.ref('hospital_management.action_report_patient_card').report_action(self)
