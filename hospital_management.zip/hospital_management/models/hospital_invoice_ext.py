# -*- coding: utf-8 -*-
from odoo import fields, models


class AccountMove(models.Model):
    _inherit = 'account.move'

    hospital_patient_id = fields.Many2one(
        'hospital.patient', string='Patient',
        domain=[('state', '!=', 'deceased')],
        copy=False,
    )
    hospital_appointment_id = fields.Many2one(
        'hospital.appointment', string='Appointment',
        copy=False,
    )
